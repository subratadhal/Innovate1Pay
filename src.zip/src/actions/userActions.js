import axios from "axios";

var headerConfig = {
  headers: {
    "Content-Type": "application/x-www-form-urlencoded"
  }
};
export function fetchUsers(){

  return function(dispatch){
    axios.get('https://reqres.in/api/users/2')
        .then((response) =>{
          dispatch({type:'FETCH_USERS_FULFILLED', payload:response.data.data});
        })
        .catch((err) => {
          dispatch({type:'FETCH_USERS_REJECTED',payload:err})
        })
  }
}

