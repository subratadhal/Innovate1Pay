import React, { Component } from 'react';
import { connect } from 'react-redux';
import logo from './logo.svg';
import './App.css';

import PostList from './components/PostList';


class App extends Component {
  render() {
    return (
      <div className="container">
        <div className="row" >
          <div className="col-md-6">
           
          </div>
          <div className="col-md-6">
            <PostList />
          </div>
        </div>
      </div>
    );
  }
}

export default App;

// import { simpleAction } from './actions/simpleAction';
// import  {fetchUsers}  from './actions/userActions';



// const mapStateToProps = state => ({
//   ...state
//  })
//  const mapDispatchToProps = dispatch => ({
//   simpleAction: () => dispatch(simpleAction()),
//   fetchUsers: () =>  dispatch(fetchUsers())
//  })
// class App extends Component {
//   simpleAction = (event) => {
//     this.props.simpleAction();
//    };
//    fetchUsers = (event) =>{
//     this.props.fetchUsers();
//    };
//  render() {
//   console.log(this.props);
//   return (
//    <div className="App">
//     <header className="App-header">
//      <img src={logo} className="App-logo" alt="logo" />
//      <h1 className="App-title">Welcome to React</h1>

//      <pre>
//       {
//         JSON.stringify(this.props)
//       }
//       </pre>
//       <button onClick={this.simpleAction}>Test redux action</button>
//       <button onClick={this.fetchUsers}>Test fetchUsers</button>
//     </header>
   
//     <p className="App-intro">
//      To get started, edit <code>src/App.js</code> and save to reload
//     </p>
//    </div>
//   );
//  }
// }
// export default connect(mapStateToProps, mapDispatchToProps)(App);


/*

import {fetchUsers} from "../actions/userActions.js"
@connect((store) => {
  // console.log("ins store",store.userReducer.users);
  return {
    users: store.userReducer.users
  }
})


export default class Main extends React.Component{
  componentWillMount(){
      this.props.dispatch(fetchUsers());
  }

  render(){
    console.log(this.props.users);
    return (
      <div>
      <UserList users ={this.props.users}/>
      </div>
    )
  }
}
*/