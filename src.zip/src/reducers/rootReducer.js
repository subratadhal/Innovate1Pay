import { combineReducers } from 'redux';
import simpleReducer from './simpleReducer';
import usersReducer from './simpleReducer';
export default combineReducers({
    usersReducer,
    simpleReducer
});